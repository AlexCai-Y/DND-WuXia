import random

class Battle():

	def __init__(self):
	
		self.rounds = 0
		self.participants = []
		self.initiatives = []
		self.current_player = None 
		self.status = "Not Started"
	
	
	def add_participant(self, player):
		self.participants.append(player)
		
		
		
	def roll_initiatives(self):
		initiatives = {}
		for participant in self.participants:
				if participant not in initiatives:
					rolled_initiative = random.randint(0, 20)
					initiatives[participant] = rolled_initiative + 					participant.initiative
		for key in initiatives:
			self.initiative.append((key, initiatives[key]))
			
		sort(self.initiatives[1])
		for initiative in self.initiatives:
			print("{0}先攻为{1}。".format(initiative[0].name, 			initiative[1]))
				
	
	def battle_start(self):
		self.status = "Started"
		self.rounds = 1
		self.roll_initiatives();
		current_player = self.initiative[0]
	
	
	def battle_pause(self):
		self.status = "Paused"
		
	
	def battle_resume(self):
		self.status = "Resumed"
		if (len(self.participants) != len(self.initiatives)):
			self.roll_initiatives()
		