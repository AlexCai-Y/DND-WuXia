class Abilitiy():

	def __init__(self, name, type, attribute, yy, ratio, weapon, effect, action, dmg_type):
		self.name = name 
		self.type = type 
		self.attribute = attribute 
		self.yy = yy
		self.ratio = ratio
		self.weapon = weapon
		self.effect = effect
		self.action = action
		self.dmg_type = dmg_type