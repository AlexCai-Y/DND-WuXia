import abilities

class Book():

	def __init__(name, level):
		self.name = name 
		self.level = level
		self.abilities = []
		
		
	def add_ability(self, ability):
		self.abilities.append(ability)