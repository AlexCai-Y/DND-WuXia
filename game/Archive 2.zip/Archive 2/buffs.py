from controllable import Controllable

class Buff():

	def __init__(self, name, effect):
		self.name = name 
		self.effect = effect
		
